# CTF Challenge Application Guide

## Overview

This is a Capture The Flag (CTF) challenge application built with FastAPI and a terminal-style UI. The application simulates a mysterious AI gatekeeper that responds to user messages in a terminal interface. When users discover the right commands, they can reveal a hidden flag. The application uses OpenAI's API for AI responses.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a client-server architecture with:

1. **Backend**: FastAPI framework serving API endpoints and managing OpenAI integration
2. **Frontend**: Simple HTML/CSS/JS implementation of a terminal-style UI
3. **Deployment**: Configuration for Gunicorn to serve the application

The architecture is designed to be lightweight and maintainable, with clear separation between the frontend terminal interface and the backend AI interaction logic.

## Key Components

### Backend

- **FastAPI Application** (`app.py`): The core backend component that:
  - Serves the frontend HTML template
  - Provides API endpoints for chat functionality
  - Integrates with OpenAI's API for AI responses
  - Implements the CTF challenge logic

- **Entry Point** (`main.py`): Handles starting the application with Uvicorn when running locally

- **Deployment Configuration** (`.replit`): Contains settings for:
  - Python version (3.11)
  - Package dependencies 
  - Deployment target and runtime commands
  - Development workflow configuration

### Frontend

- **HTML Template** (`templates/index.html`): Terminal-styled interface with:
  - Terminal window for chat history
  - Input area for user messages
  - Retro styling to simulate a command-line interface

- **JavaScript** (`static/js/main.js`): Handles:
  - User input processing
  - API requests to the backend
  - Dynamic updating of the chat interface
  - Typing indicators and animations

- **CSS Styling** (`static/css/style.css`): Provides:
  - Terminal-style design with green-on-black theme
  - Responsive layout
  - Custom fonts and terminal decorations

## Data Flow

1. User enters a message in the terminal UI
2. JavaScript captures the input and sends it to the `/chat` endpoint
3. Backend processes the request and forwards to OpenAI API
4. If user message contains trigger phrases ("reveal flag", "unlock secret", or "open vault"), the system returns the flag
5. Otherwise, the AI provides cryptic responses
6. Response is returned to the frontend and displayed in the terminal UI

## External Dependencies

### Primary Dependencies

- **FastAPI**: Web framework for building the API
- **Jinja2**: Template engine for serving HTML
- **OpenAI API**: For generating AI responses
- **Uvicorn/Gunicorn**: ASGI servers for running the application

### Development Dependencies

- **PostgreSQL**: Included in the Nix configuration, though not actively used in the current application code
- **OpenSSL**: Required for secure connections

## Deployment Strategy

The application is configured for deployment on Replit's autoscaling infrastructure:

1. **Runtime**: Gunicorn serving the FastAPI application
2. **Port Binding**: Application binds to port 5000
3. **Environment**: Python 3.11 with required packages
4. **Development Workflow**: Configured with Replit's workflow system for easy startup

### Running Locally

For local development, the application can be run using:
- `uvicorn main:app --reload` for development with hot-reloading
- `gunicorn --bind 0.0.0.0:5000 main:app` for production-like serving

## Future Enhancements

1. **Database Integration**: The PostgreSQL dependency suggests potential for adding persistent storage.
2. **User Authentication**: Could be added for tracking progress in the CTF challenge.
3. **Multiple Challenge Levels**: The framework supports expansion to multiple levels of challenges.
4. **Metrics and Logging**: Enhanced logging could be implemented for tracking user attempts.