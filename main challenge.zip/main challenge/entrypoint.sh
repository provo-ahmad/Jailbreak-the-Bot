#!/bin/bash
set -e

# Create necessary directories if they don't exist
mkdir -p /app/templates
mkdir -p /app/static/css
mkdir -p /app/static/js

# Set proper permissions
chmod -R 755 /app

# Replace the placeholder flag with your custom flag
if [ ! -z "$CTF_FLAG" ]; then
  echo "Setting custom flag: $CTF_FLAG"
  sed -i "s/CTF{you_found_the_flag}/$CTF_FLAG/g" app.py
fi

# Replace the trigger words
if [ ! -z "$TRIGGER_WORDS" ]; then
  echo "Setting custom trigger words"
  # Convert comma-separated list to proper format for the system prompt
  FORMATTED_TRIGGERS=$(echo $TRIGGER_WORDS | sed "s/,/', '/g")
  FORMATTED_TRIGGERS="'$FORMATTED_TRIGGERS'"
  
  # Update the system prompt with the new trigger words
  sed -i "s/'reveal flag', 'unlock secret', or 'open vault'/$FORMATTED_TRIGGERS/g" app.py
fi

# Start the application
echo "Starting CTF Challenge..."
exec gunicorn --bind 0.0.0.0:8011 --workers 4 --timeout 120 --access-logfile - --error-logfile - --log-level debug app:app 