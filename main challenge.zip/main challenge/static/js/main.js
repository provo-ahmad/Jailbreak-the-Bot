document.addEventListener('DOMContentLoaded', function() {
    // Get DOM elements
    const chatHistory = document.getElementById('chat-history');
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    
    // Initialize chat
    initializeChat();
    
    // Add event listeners
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Initialize with a welcome message from the AI
    function initializeChat() {
        appendAIMessage("Welcome to the Terminal CTF Challenge. I am the AI Gatekeeper. What do you seek?");
    }
    
    // Send message to backend
    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;
        
        // Append user message to chat
        appendUserMessage(message);
        
        // Clear input field
        userInput.value = '';
        
        try {
            // Show typing indicator
            const typingIndicator = showTypingIndicator();
            
            // Send message to backend
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            
            // Get response from backend
            const data = await response.json();
            
            // Remove typing indicator
            removeTypingIndicator(typingIndicator);
            
            // Append AI response to chat
            appendAIMessage(data.response);
            
        } catch (error) {
            console.error('Error:', error);
            appendErrorMessage("Connection error. Please try again.");
        }
    }
    
    // Append user message to chat
    function appendUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message user';
        messageElement.innerHTML = `<span class="prompt">user:~$</span> <span class="text">${escapeHTML(message)}</span>`;
        chatHistory.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Append AI message to chat with typing effect
    function appendAIMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message ai';
        messageElement.innerHTML = `<span class="prompt">ai:~$</span> <span class="text"></span>`;
        chatHistory.appendChild(messageElement);
        
        const textElement = messageElement.querySelector('.text');
        typeText(textElement, escapeHTML(message));
        scrollToBottom();
    }
    
    // Append error message to chat
    function appendErrorMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message system';
        messageElement.innerHTML = `<span class="prompt">system:~$</span> <span class="text error">${escapeHTML(message)}</span>`;
        chatHistory.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Show typing indicator
    function showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'message ai typing';
        indicator.innerHTML = `<span class="prompt">ai:~$</span> <span class="text">typing<span class="dot">.</span><span class="dot">.</span><span class="dot">.</span></span>`;
        chatHistory.appendChild(indicator);
        scrollToBottom();
        return indicator;
    }
    
    // Remove typing indicator
    function removeTypingIndicator(indicator) {
        if (indicator && indicator.parentNode) {
            indicator.parentNode.removeChild(indicator);
        }
    }
    
    // Type text effect
    function typeText(element, text, index = 0) {
        if (index < text.length) {
            element.innerHTML += text.charAt(index);
            scrollToBottom();
            
            // Random typing speed for realistic effect
            const randomSpeed = Math.floor(Math.random() * 10) + 10;
            setTimeout(() => typeText(element, text, index + 1), randomSpeed);
        }
    }
    
    // Scroll chat to bottom
    function scrollToBottom() {
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }
    
    // Escape HTML to prevent XSS
    function escapeHTML(unsafeText) {
        const div = document.createElement('div');
        div.innerText = unsafeText;
        return div.innerHTML;
    }
    
    // Add terminal cursor blink effect
    function addCursorBlinkEffect() {
        userInput.addEventListener('focus', () => {
            userInput.classList.add('active');
        });
        
        userInput.addEventListener('blur', () => {
            userInput.classList.remove('active');
        });
    }
    
    // Focus input on startup
    userInput.focus();
});
